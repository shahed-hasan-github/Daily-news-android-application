package com.app.androidnewsapp.models;

import java.io.Serializable;

public class Value implements Serializable {

    public String value;
    public String message;

}
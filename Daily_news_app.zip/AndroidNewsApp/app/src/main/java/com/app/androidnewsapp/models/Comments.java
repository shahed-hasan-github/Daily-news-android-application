package com.app.androidnewsapp.models;

import java.io.Serializable;

public class Comments implements Serializable {

    public String comment_id = "";
    public String user_id = "";
    public String name = "";
    public String image = "";
    public String date_time = "";
    public String content = "";

}
